# drawing-classifier
A Python application which uses machine learning classification algorithms to classify drawings of the user.

NEURALNINE (c) 2019
Drawing Classifier ML Alpha v0.1

This script allows you to define three custom classes and then to draw the respective drawings. By clicking the buttons of the individual classes, you add one training file to the model. Then you can train it (choose one of multiple classifiers) and predict future drawings.

This is the very first prototype and the code is not clean at all
Also there may be a couple of bugs
A lot of exceptions are not handled